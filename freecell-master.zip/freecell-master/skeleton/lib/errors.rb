class UserError < StandardError
end
