class Board < ActiveRecord::Base
end
