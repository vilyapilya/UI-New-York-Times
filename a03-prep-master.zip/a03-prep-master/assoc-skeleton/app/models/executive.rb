class Executive < ActiveRecord::Base
end
