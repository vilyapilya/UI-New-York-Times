class WatchList < ActiveRecord::Base
end
