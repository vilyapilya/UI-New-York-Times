require "hand"

describe Hand do
  subject(:hand) { Hand.new }

  describe
end
